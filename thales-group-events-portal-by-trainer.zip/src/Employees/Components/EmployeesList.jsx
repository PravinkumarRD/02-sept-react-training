export const EmployeesList = () => {
  return (
    <>
        <h1>Welcome To Thales Group Employees List!</h1>
        <hr />
        <h6>Core Development Members of India!</h6>
    </>
  )
}
