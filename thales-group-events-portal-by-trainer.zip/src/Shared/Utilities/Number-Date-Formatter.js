function formatDate(locale = "en-IN", dateValue = new Date()) {
    return Intl.DateTimeFormat(locale, {
        weekday: 'long',
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date(dateValue));
}

function formatCurrency(locale = "en-IN", symbol = "INR", value = 0) {
    return Intl.NumberFormat(locale, {
        style: 'currency',
        currency: symbol,
        maximumFractionDigits: 2,
        minimumFractionDigits: 2
    }).format(value)
}

export { formatDate, formatCurrency }