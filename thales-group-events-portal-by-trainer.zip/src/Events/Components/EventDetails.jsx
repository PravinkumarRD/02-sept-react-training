import { useState, useEffect } from "react";
import { useParams } from "react-router";

import { getEventDetails } from "../Services/EventsService";

import { formatDate, formatCurrency } from "../../Shared/Utilities/Number-Date-Formatter";

//export const EventDetails = ({ event }) => {
const EventDetails = () => {
    let title = "Details Of - ";
    const [event, setEvent] = useState(null);
    let params = useParams();
    useEffect(() => {
        (async () => {
            setEvent(await getEventDetails(params.id));
        })();
    }, [params.id]);
    if (event) {
        return (
            <>
                <h1>{title + event.eventName}</h1>
                <hr />
                <table className="table table-hover table-striped">
                    <tbody>
                        <tr>
                            <th>Event Id</th>
                            <td>{event.eventId}</td>
                        </tr>
                        <tr>
                            <th>Event Code</th>
                            <td>{event.eventCode}</td>
                        </tr>
                        <tr>
                            <th>Event Name</th>
                            <td>{event.eventName}</td>
                        </tr>
                        <tr>
                            <th>Description</th>
                            <td>{event.description}</td>
                        </tr>
                        <tr>
                            <th>Start Date</th>
                            <td>{formatDate("hi-IN", event.startDate)}</td>
                        </tr>
                        <tr>
                            <th>End Date</th>
                            <td>{formatDate("hi-IN", event.endDate)}</td>
                        </tr>
                        <tr>
                            <th>Seats Occupied</th>
                            <td>
                                <div className="progress" role="progressbar" aria-label="Animated striped example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                                    <div className="progress-bar progress-bar-striped progress-bar-animated"
                                        style={{ width: event.seatsFilled + '%' }} title={event.seatsFilled + '%'}>
                                        {event.seatsFilled + '%'}
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>Event Fees</th>
                            <td>{formatCurrency("en-IN", "INR", event.fees)}</td>
                        </tr>
                        <tr>
                            <th>Logo</th>
                            <td>
                                <img src={event.logo} alt={event.eventName} />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </>
        )
    } else {
        <>
            <h4>Loading your selected event details!</h4>
        </>
    }

}

export default EventDetails;