import { useState, useEffect, useReducer } from 'react';

import { getAllEvents, getEventDetails } from "../Services/EventsService";

import { formatDate, formatCurrency } from "../../Shared/Utilities/Number-Date-Formatter";

import { EventDetails } from "./EventDetails";

const InitialState = {
    events: [],
    event: null
}

function reducer(state = InitialState, action) {
    switch (action.type) {
        case "FETCH_ALL_EVENTS":
            state = {
                ...state,
                events: action.payload
            }
            break;
        case "FETCH_EVENT_DETAILS_ID":
            state = {
                ...state,
                event: action.payload
            }
            break;
        default:
            break;
    }
    return state;
}

export const EventsList = () => {
    const title = "Welcome To Thales Group Events List!";
    const subTitle = "Published by Global Hr Team! India!";

    const [state, dispatch] = useReducer(reducer, InitialState);

    useEffect(() => {
        //IIFE - Immediately Invoked Function Expression
        (async ()=>{
            dispatch({ type: "FETCH_ALL_EVENTS", payload:await getAllEvents() });
        })()
        return () => {
            console.log('This is where you write clean-up logic == componentWillUnMount()');
        }
    }, []);
    const onEventSelection = async (eventId) => {
        console.log(eventId);
        dispatch({ type: "FETCH_EVENT_DETAILS_ID", payload: await getEventDetails(eventId) });
    }
    if (state.events.length > 0) {
        return (
            <>
                <h1>{title}</h1>
                <hr />
                <h6>{subTitle}</h6>
                <table className="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Event Code</th>
                            <th>Event Name</th>
                            <th>Start Date</th>
                            <th>Fees</th>
                            <th>Show Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            state.events.map(event =>
                                <tr key={event.eventId}>
                                    <td>{event.eventCode}</td>
                                    <td>{event.eventName}</td>
                                    <td>{formatDate("hi-IN", event.startDate)}</td>
                                    <td>{formatCurrency("en-IN", "INR", event.fees)}</td>
                                    <td>
                                        <button className="btn btn-info" onClick={() => onEventSelection(event.eventId)}>Show Details</button>
                                    </td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
                {state.event ? <EventDetails event={state.event} /> : ''}
            </>
        )
    }
    return (
        <h1>Loading...</h1>
    )
}


//This example is using useState() hook

// export const EventsList = () => {
//     const [events, setEvents] = useState([]);
//     const [event, setEvent] = useState(null);
//     const title = "Welcome To Thales Group Events List!";
//     const subTitle = "Published by Global Hr Team! India!";
//     //Class Component - componentDidMount(), componentDidUpdate(), componentWillUnMount()
//     useEffect(() => {
//         //login
//         setEvents(getAllEvents());
//         return () => {
//             console.log('This is where you write clean-up logic == componentWillUnMount()');
//         }
//     }, []);
//     const onEventSelection = (eventId) => {
//         console.log(eventId);
//         setEvent(getEventDetails(eventId));
//     }
//     if (events.length > 0) {
//         return (
//             <>
//                 <h1>{title}</h1>
//                 <hr />
//                 <h6>{subTitle}</h6>
//                 <table className="table table-hover table-striped">
//                     <thead>
//                         <tr>
//                             <th>Event Code</th>
//                             <th>Event Name</th>
//                             <th>Start Date</th>
//                             <th>Fees</th>
//                             <th>Show Details</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {
//                             events.map(event =>
//                                 <tr key={event.eventId}>
//                                     <td>{event.eventCode}</td>
//                                     <td>{event.eventName}</td>
//                                     <td>{event.startDate.toString()}</td>
//                                     <td>{event.fees}</td>
//                                     <td>
//                                         <button className="btn btn-info" onClick={() => onEventSelection(event.eventId)}>Show Details</button>
//                                     </td>
//                                 </tr>
//                             )
//                         }
//                     </tbody>
//                 </table>
//                 {event ? <EventDetails event={event} /> : ''}
//             </>
//         )
//     }
//     return (
//         <h1>Loading...</h1>
//     )
// }
