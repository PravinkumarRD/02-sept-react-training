import { Navigate, Outlet } from "react-router";

export const ProtectedRoute = ({ isAuthenticated, children, returnUrl }) => {
  if (!isAuthenticated) {
    return <Navigate to={`/login?returnurl=${returnUrl}`} />;
  }
  return children ? children : <Outlet />;
};