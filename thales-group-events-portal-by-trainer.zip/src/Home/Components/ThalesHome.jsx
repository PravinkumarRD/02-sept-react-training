export const ThalesHome = () => {
    return (
        <>
            <h1>Welcome To Thales Group Events Portal!</h1>
            <hr />
            <h6>Designed and Developed by Core Members of India!</h6>
        </>
    )
}
