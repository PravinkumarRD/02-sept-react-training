import axios from "../../Ajax/axios-instance";

async function authenticateCredentails(user) {
    console.log(user);
    return await (
        await axios.post("/users/authenticate", user)
    ).data;
}

async function registerUser(user) {
    console.log(user);
    return await (
        await axios.post("/users", user)
    ).data;
}

export { authenticateCredentails, registerUser }