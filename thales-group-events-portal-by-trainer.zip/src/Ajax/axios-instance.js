import axios from "axios";

const axiosInstance = axios.create({
    baseURL: 'http://localhost:9090/api',
});

axiosInstance.interceptors.request.use((config) => {
    if(config.url.includes('/authentication')){
        
    }
    config.headers.set("Content-Type", "application/json");
    config.headers.set("thales-authorization-token", "my-custom-token");
    return config;
});

export default axiosInstance;