import axios from "axios";

import { getTokenFromLocalStorage } from "../Shared/Utilities/localStorageUtility";

const axiosInstance = axios.create({
    baseURL: 'http://localhost:9090/api',
});

axiosInstance.interceptors.request.use((config) => {
    config.headers.set("Content-Type", "application/json");
    if (!config.url.includes('users') && getTokenFromLocalStorage("token") === true) {
        config.headers.set("thales-authorization-token", localStorage.getItem("token"));
    }
    return config;
});

export default axiosInstance;