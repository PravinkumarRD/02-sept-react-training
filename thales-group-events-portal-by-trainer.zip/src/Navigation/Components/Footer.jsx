export const Footer = () => {
    return (
        <>
            <hr />
            <p style={{ textAlign: 'center' }}>&copy; All Rights Reserved by Thales Group Ltd.</p>
        </>
    )
}
