import { useState } from 'react'
import { EventsList } from "./Events/Components/EventsList";

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <h1>Welcome To Thales Group Events Portal!</h1>
      <hr />
      <h6>Designed and Developed by Thales Developers!</h6> */}
      <EventsList />
    </>
  )
}

export default App
