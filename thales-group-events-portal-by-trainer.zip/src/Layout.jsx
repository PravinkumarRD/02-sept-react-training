import { lazy, Suspense } from "react";

import { Routes, Route, useLocation } from "react-router";

import { getTokenFromLocalStorage } from "./Shared/Utilities/localStorageUtility";

import { Navbar } from "./Navigation/Components/Navbar";
import { Footer } from "./Navigation/Components/Footer";

import { ThalesHome } from "./Home/Components/ThalesHome";
import { EmployeesList } from "./Employees/Components/EmployeesList";
// import { EventsList } from "./Events/Components/EventsList";
const EventsList = lazy(() => import("./Events/Components/EventsList"));
//import { EventDetails } from "./Events/Components/EventDetails";
const EventDetails = lazy(() => import("./Events/Components/EventDetails"));
import { Login } from "./Security/Components/Login";

import { ProtectedRoute } from "./ProtectedRoutes";

export const Layout = () => {
    const location = useLocation();
    return (
        <>
            <Navbar />
            <Suspense fallback={<><h3>Hello...</h3></>}>
                <Routes>
                    <Route index path="/" element={<><h1>Default Route from React Router Library!</h1></>} />
                    <Route path="/home" element={<ThalesHome />} />
                    <Route path="/employees" element={<EmployeesList />} />
                    <Route element={<ProtectedRoute isAuthenticated={getTokenFromLocalStorage("token")} returnUrl={location.pathname} />}>
                        <Route path="/events" element={<EventsList />} />
                        <Route path="/events/:id" element={<EventDetails />} />
                    </Route>
                    <Route path="/login" element={<Login />} />
                </Routes>
            </Suspense>
            <Footer />
        </>
    )
}
