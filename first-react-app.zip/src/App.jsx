import { ComponentOne } from "./Components/ComponentOne";
import { ComponentTwo } from "./Components/ComponentTwo";


function App() {
  console.log('Root Component!');
  const title = "Welcome To Thales Group Ltd.";
  return (
    <>
      {/* <h1 title={"Thales Group"}>{title}</h1>
      <hr />
      <h6>Location - Delhi - Noida!</h6> */}
      <ComponentOne/>
      <hr />
      <ComponentTwo/>
    </>
  )
}

export default App
