import StyleOne from './ComponentOne.module.css';

export const ComponentOne = () => {
    const componentOneStyleObject = {
        "textAlign": "right",
        "color": "green"
    }
    return (
        <>
            {/* <h1 style={{ textAlign: 'center', color: 'green' }}>Welcome To Component One - From Delhi</h1>
            <hr />
            <h6 style={{ textAlign: 'center', color: 'yellowgreen' }}>Designed and Developed by Delhi Developers</h6> */}
            {/* <h1 style={componentOneStyleObject}>Welcome To Component One - From Delhi</h1>
            <hr />
            <h6 style={{ ...componentOneStyleObject, color: 'purple' }}>Designed and Developed by Delhi Developers</h6> */}
            <h1 className={StyleOne.title}>Welcome To Component One - From Delhi</h1>
            <hr />
            <h6 className={StyleOne.subTitle}>Designed and Developed by Delhi Developers</h6>
        </>
    )
}

//Spread operator
