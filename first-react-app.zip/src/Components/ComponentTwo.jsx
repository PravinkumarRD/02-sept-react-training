import  StyleTwo from  './ComponentTwo.module.css';

export const ComponentTwo = () => {
    return (
        <>
            <h1 className={StyleTwo.title}>Welcome To Component One - From Mumbai</h1>
            <hr />
            <h6 className={StyleTwo.subTitle}>Designed and Developed by Mumbai Developers</h6>
        </>
    )
}
