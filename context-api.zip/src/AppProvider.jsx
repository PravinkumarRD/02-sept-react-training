import React, { Component } from "react";

export const AppContext = React.createContext();
AppContext.displayName = "MyAppContext"; //For Developers used in React-Dev-Tool

export default class AppProvider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "Hello from Root Component!!!",
      loginStatus: "Login"
    };
  }
  render() {
    return (
      <AppContext.Provider
        value={{
          state: this.state,
          changeState: (msg) =>
            this.setState({
              message: msg,
            }),
          loginLogout: () => {
            let status = this.state.loginStatus === "login" ? "Logout" : "login";
            this.setState({
              loginStatus: status
            }, () => console.log(this.state))
          }
        }}
      >
        {this.props.children}
      </AppContext.Provider>
    );
  }
}
