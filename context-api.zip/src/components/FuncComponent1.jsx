import { useContext } from "react";
import { AppContext } from "../AppProvider";

export const FuncComponent1 = () => {
  const context = useContext(AppContext);
  return (
    <div>
      <h2>{context.state.message}</h2>
      <hr/>
      <button onClick={()=>{context.changeState("Hello! From Functional Component - 1");context.loginLogout("Logout")}}>Change State!</button>
    </div>
  );
};
