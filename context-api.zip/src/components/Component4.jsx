import { Component } from "react";
import { AppContext } from "../AppProvider";

import { FuncComponent1 } from "./FuncComponent1";

export default class Component4 extends Component {
  render() {
    return (
      <div>
        <AppContext.Consumer>
          {(context) => (
            <div>
              <h1>This is Component - 4</h1>
              <h3>Received message from Provider is - </h3>
              <h5>{context.state.message}</h5>
              <hr />
              <button
                onClick={() => context.changeState("Hello! From Component - 4")}
              >
                Change State!
              </button>
            </div>
          )}
        </AppContext.Consumer>
        <FuncComponent1 />
      </div>
    );
  }
}
