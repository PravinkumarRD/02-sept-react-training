import React, { Component } from "react";

import Component4 from "./Component4";
//import { FuncComponent1 } from "./FuncComponent1";

export default class Component3 extends Component {
  render() {
    return (
      <div>
        <h1>This is Component - 3</h1>
        <Component4 />
        <hr />
        {/* <FuncComponent1 /> */}
      </div>
    );
  }
}
