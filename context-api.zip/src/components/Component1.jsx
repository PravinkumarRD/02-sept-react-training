import { Component } from "react";

import Component2 from "./Component2";

export default class Component1 extends Component {

  render() {
    return (
      <div>
        <h1>This is Component - 1</h1>
        <Component2/>
      </div>
    );
  }
}
