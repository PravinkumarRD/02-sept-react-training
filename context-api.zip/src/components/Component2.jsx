import  { Component } from "react";
import { AppContext } from "../AppProvider";

import Component3 from "./Component3";

export default class Component2 extends Component {
  render() {
    return (
      <div>
        <AppContext.Consumer>
          {(context) => (
            <div>
              <h1>This is Component - 2</h1>
              <h3>Received message from Provider is - </h3>
              <h5>{context.state.message}</h5>
              <hr />
              <button
                onClick={() => context.changeState("Hello! From Component - 2!!!!")}
              >
                Change State!
              </button>
            </div>
          )}
        </AppContext.Consumer>
        <Component3 />
      </div>
    );
  }
}
