import { Component } from "react";

import AppProvider from "./AppProvider";

import Component1 from "./components/Component1";

export default class App extends Component {
  render() {
    return (
      <AppProvider>
        <Component1 />
      </AppProvider>
    );
  }
}
