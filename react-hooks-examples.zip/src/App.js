// import { UseStateExample } from "./Components/UseStateExample";
// import { UseEffectExample } from "./Components/UseEffectExample";
// import { UseMemoExample } from "./Components/UseMemoExample";
import { UseCallBackExample } from "./Components/UseCallBackExample";
// import { UseReducerExample } from "./Components/UseReducerExample";
// import { UseRefExample } from "./Components/UseRefExample";
// import { UseIdExample } from "./Components/UseIdExample";
// import { UseTransitionExample } from "./Components/UseTransitionExample";

function App() {
  return (
    <div className="container">
      <h1>Welcome To React Hooks Examples!</h1>
      <hr />
      {/* <UseStateExample /> */}
      {/* <UseEffectExample /> */}
      {/* <UseMemoExample /> */}
      <UseCallBackExample/>
      {/* <UseReducerExample /> */}
      {/* <UseRefExample /> */}
      {/* <UseIdExample/> */}
      {/* <UseTransitionExample /> */}
    </div>
  );
}

export default App;
