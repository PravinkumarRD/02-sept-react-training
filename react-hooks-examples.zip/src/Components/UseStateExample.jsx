import { useState } from "react";

export const UseStateExample = () => {
  //Array Destructuring Syntax - ES6
  let [counter, setCounter] = useState(0);
  return (
      <div>
          <h1>{counter}</h1>
          <hr />
          <button className="btn btn-dark" onClick={() => setCounter(counter = counter + 1)}>Increment Class Counter!</button>
      </div>
  );
};
