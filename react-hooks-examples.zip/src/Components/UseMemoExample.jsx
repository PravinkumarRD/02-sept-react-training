// Problem Statement
/*
import { useState } from "react";

export const UseMemoExample = () => {
  const [number, setNumber] = useState(0);
  const squaredNum = square(number);
  const [counter, setCounter] = useState(0);

  const onChangeHandler = (e) => {
    setNumber(e.target.value);
  };

  const incrementCounter = () => {
    setCounter(counter + 1);
  };
  return (
    <div className="App">
      <h1>When should I use useMemo() hook?</h1>
      <input
        type="number"
        placeholder="Enter a number"
        value={number}
        onChange={onChangeHandler}
      ></input>

      <div>Square is -: {squaredNum}</div>
      <button onClick={incrementCounter}>Increment Counter</button>
      <div>Counter Value is -: {counter}</div>
    </div>
  );
};

// Function to square the value
function square(number) {
  console.log(`Calculating the square of ${number}!`);
  return number * number;
}*/
//Solution - useMemo() hook
import { useState, useMemo } from "react";

export const UseMemoExample = () => {
  const [number, setNumber] = useState(0);
  const squaredNum = useMemo(() => square(number), [number]);
  const [counter, setCounter] = useState(0);

  const onChangeHandler = (e) => {
    setNumber(e.target.value);
  };

  const incrementCounter = () => {
    setCounter(counter + 1);
  };
  return (
    <div className="App">
      <h1>When should I use useMemo() hook?</h1>
      <input
        className="form-control"
        type="number"
        placeholder="Enter a number"
        value={number}
        onChange={onChangeHandler}
      />

      <div>Square is -: {squaredNum}</div>
      <button className="btn btn-success" onClick={incrementCounter}>
        Increment Counter
      </button>
      <div>Counter Value is -: {counter}</div>
    </div>
  );
};

// Function to square the value
function square(number) {
  console.log(`Calculating the square of ${number}!`);
  return number * number;
}