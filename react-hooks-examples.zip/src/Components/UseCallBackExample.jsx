import { useState, useCallback, useEffect } from "react";

const DisplayItems = ({ getPostsList }) => {
  const [items, setItems] = useState([]);
  useEffect(() => {
    setItems(getPostsList());
    console.log("Number Changed and Items received!");
  }, [getPostsList]);
  return items.map((post) => <div key={post}>{post}</div>);
};

export const UseCallBackExample = () => {
  const [number, setNumber] = useState(0);

  const [counter, setCounter] = useState(0);
  const getPostsItems = useCallback(() => {
    return [number + 5, number + 10, number + 20];
  }, [number]);
  // const getPostsItems = () => {
  //   return [number + 5, number + 10, number + 20];
  // };
  const onChangeHandler = (e) => {
    setNumber(e.target.value);
  };

  const incrementCounter = () => {
    setCounter(counter + 1);
  };
  return (
    <div className="App">
      <h1>When should I use useCallBack() hook?</h1>
      <input
        className="form-control"
        type="number"
        placeholder="Enter a number"
        value={number}
        onChange={onChangeHandler}
      />
      <button className="btn btn-success" onClick={incrementCounter}>
        Increment Counter
      </button>
      <div>Counter Value is -: {counter}</div>
      <div>Changed Number is -: {number}</div>
      <DisplayItems getPostsList={getPostsItems} />
    </div>
  );
};
