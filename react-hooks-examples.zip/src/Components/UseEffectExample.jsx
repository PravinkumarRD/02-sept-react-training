import { useState, useEffect } from "react";

export const UseEffectExample = () => {
  let title = "JsonPlaceHolder Posts List!";
  let url = "https://jsonplaceholder.typicode.com/posts";
  const [posts, setPosts] = useState(null);
  useEffect(() => {
    (async () => {
      const posts = await (await fetch(url)).json();
      setPosts(posts);
    })();
    return ()=>{
      //Clean-up/Unmounting
    }
  }, [url]);

  if (posts) {
    return (
      <div>
        <h1>{title}</h1>
        <br />
        <table className="table table-hover table-striped">
          <thead>
            <tr>
              <th>User Id</th>
              <th>Post Id</th>
              <th>Post Title</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {posts.map((post) => (
              <tr key={post.id}>
                <td>
                  <span>{post.userId}</span>
                </td>
                <td>
                  <span>{post.id}</span>
                </td>
                <td>
                  <span>{post.title}</span>
                </td>
                <td>
                  <span>{post.body}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  } else {
    return <h4>Loading...</h4>;
  }
};
