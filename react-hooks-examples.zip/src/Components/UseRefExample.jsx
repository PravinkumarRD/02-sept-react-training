import { useRef } from "react";

export const UseRefExample = () => {
  const gotDescription = useRef(null);
  const onClickHandler = () => {
    gotDescription.current.value = "Nine noble families wage war against each other in order to gain control over the mythical land of Westeros. Meanwhile, a force is rising after millenniums and threatens the existence of living men.";
    gotDescription.current.focus();
  };
  console.log('Rendering Game-Of-Thrones Component!');
  return (
    <>
      <div>
        <button className="btn btn-info" onClick={onClickHandler}>Game Of Thrones!</button>
      </div>
      <label>Click here to know about Game Of Thrones!</label>
      <br />
      <textarea rows={5} className="form-control" ref={gotDescription} />
    </>
  );
}
