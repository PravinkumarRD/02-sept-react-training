export const DocumentMetadataExample = () => {
    const User={
        profile:"Corporate Trainer",
        contactName:"Manish Sharma"
    };
  return (
    <>
      <h1>Document Metadata Example!</h1>
      <title>{User.profile}</title>
      <meta name="author" content="Josh" />
      <link rel="author" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/5.3.3/united/bootstrap.rtl.min.css" />
      <meta name="keywords" content={User.contactName} />
    </>
  );
};
