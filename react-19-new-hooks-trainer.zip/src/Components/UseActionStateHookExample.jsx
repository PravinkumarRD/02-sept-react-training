"use client";

import { useActionState } from "react";

async function submitForm(prevState, formData) {
  const name = formData.get("name");

  // Simulating a server-side delay
  await new Promise((resolve) => setTimeout(resolve, 1500));

  if (!name) {
    return { success: false, message: "Name is required!" };
  }

  return { success: true, message: `Hello, ${name}! 🎉` };
}

export default function UseActionStateHookExample() {
  // useActionState manages the form action and state
  const [state, formAction] = useActionState(submitForm, { success: null, message: "" });

  return (
    <div style={{ padding: "20px", background: "#f3f3f3", borderRadius: "10px" }}>
      <h2 style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "10px" }}>
        React 19 <code>useActionState()</code> Hook Demo
      </h2>

      <form action={formAction} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <input
          type="text"
          name="name"
          placeholder="Enter your name"
          style={{ padding: "10px", border: "1px solid #ccc", borderRadius: "5px" }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            background: "#007bff",
            color: "white",
            borderRadius: "5px",
            border: "none",
            cursor: "pointer",
          }}
        >
          Submit
        </button>
      </form>

      {state.message && (
        <p style={{ marginTop: "10px", fontWeight: "bold", color: state.success ? "green" : "red" }}>
          {state.message}
        </p>
      )}
    </div>
  );
}
