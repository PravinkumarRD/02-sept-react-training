"use client";

import { useOptimistic, useState, startTransition } from "react";

// Simulated API call
async function fakeServerUpdate(comment) {
  await new Promise((resolve) => setTimeout(resolve, 2000));
  return comment; // Normally, this would return a server response
}

export default function UseOptimisticExample() {
  // State for comments
  const [comments, setComments] = useState(["Great post!", "Nice explanation!"]);

  // Optimistic UI state
  const [optimisticComments, addOptimisticComment] = useOptimistic(comments, (prev, newComment) => [
    ...prev,
    newComment,
  ]);

  // Handle form submission
  async function handleSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const newComment = formData.get("comment");

    if (!newComment) return;

    // Wrap optimistic update inside startTransition
    startTransition(() => {
      addOptimisticComment(newComment);
    });

    await fakeServerUpdate(newComment); // Simulated server update
    setComments((prev) => [...prev, newComment]); // Actual state update
    event.target.reset(); // Clear input field
  }

  return (
    <div style={{ padding: "20px", background: "#f3f3f3", borderRadius: "10px" }}>
      <h2 style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "10px" }}>
        React 19 <code>useOptimistic()</code> Hook Demo
      </h2>

      <form onSubmit={handleSubmit} style={{ display: "flex", gap: "10px", marginBottom: "10px" }}>
        <input
          type="text"
          name="comment"
          placeholder="Add a comment..."
          style={{ padding: "10px", border: "1px solid #ccc", borderRadius: "5px", flexGrow: 1 }}
        />
        <button
          type="submit"
          style={{
            padding: "10px",
            background: "#007bff",
            color: "white",
            borderRadius: "5px",
            border: "none",
            cursor: "pointer",
          }}
        >
          Post
        </button>
      </form>

      <ul style={{ listStyle: "none", padding: 0 }}>
        {optimisticComments.map((comment, index) => (
          <li
            key={index}
            style={{
              padding: "10px",
              marginBottom: "5px",
              background: index >= comments.length ? "#d1e7fd" : "#ffffff",
              borderRadius: "5px",
            }}
          >
            {comment} {index >= comments.length && <small>(Optimistic)</small>}
          </li>
        ))}
      </ul>
    </div>
  );
}
