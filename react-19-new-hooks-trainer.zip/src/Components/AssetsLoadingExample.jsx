export const AssetsLoadingExample = () => {
  return <h1>Assets Loading Example!</h1>;
};
