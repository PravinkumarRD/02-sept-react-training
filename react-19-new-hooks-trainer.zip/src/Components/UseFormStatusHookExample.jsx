"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";
// Simulated async form submission function
async function submitForm(prevState, formData) {
  const name = formData.get("name");
  const companyName = formData.get("companyName");

  // Simulating a server-side delay
  await new Promise((resolve) => setTimeout(resolve, 2000));

  if (!name) {
    return { success: false, message: "Name is required!" };
  }

  return { success: true, message: `Hello, ${name}! Welcome To Company - ${companyName} 🎉` };
}

export const CustomTextBox = () => {
  return (
    <>
      <input
        type="text"
        name="companyName"
        placeholder="Enter your company name"
        style={{
          padding: "10px",
          border: "1px solid #ccc",
          borderRadius: "5px",
        }}
      />
      <SubmitButton />
    </>
  );
};

// Submit Button Component using useFormStatus
function SubmitButton() {
  const { pending } = useFormStatus(); // Tracks the form submission state

  return (
    <button
      type="submit"
      disabled={pending}
      style={{
        padding: "10px",
        background: pending ? "#aaa" : "#007bff",
        color: "white",
        borderRadius: "5px",
        border: "none",
        cursor: pending ? "not-allowed" : "pointer",
      }}
    >
      {pending ? "Submitting..." : "Submit"}
    </button>
  );
}

// Main Component
export default function UseFormStatusHookExample() {
  const [state, formAction] = useActionState(submitForm, {
    success: null,
    message: "",
  });

  return (
    <div
      style={{ padding: "20px", background: "#f3f3f3", borderRadius: "10px" }}
    >
      <h2
        style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "10px" }}
      >
        React 19 <code>useFormStatus()</code> Hook Demo
      </h2>

      <form
        action={formAction}
        style={{ display: "flex", flexDirection: "column", gap: "10px" }}
      >
        <input
          type="text"
          name="name"
          placeholder="Enter your name"
          style={{
            padding: "10px",
            border: "1px solid #ccc",
            borderRadius: "5px",
          }}
        />
        <CustomTextBox />
      </form>

      {state.message && (
        <p
          style={{
            marginTop: "10px",
            fontWeight: "bold",
            color: state.success ? "green" : "red",
          }}
        >
          {state.message}
        </p>
      )}
    </div>
  );
}
