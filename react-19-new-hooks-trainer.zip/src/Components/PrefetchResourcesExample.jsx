"use client";

import { prefetchDNS, preconnect, preload, preinit } from "react-dom";

export default function ResourceOptimizationExample() {
  // Prefetch DNS for an external API
  prefetchDNS("https://api.example.com");

  // Preconnect to an external image CDN
  preconnect("https://cdn.example.com");

  // Preload an image to improve rendering performance
  preload("https://cdn.example.com/image.jpg", { as: "image" });

  // Preinit a script for faster execution
  preinit("https://code.jquery.com/jquery-3.7.1.slim.js", { as: "script" });

  return (
    <div
      style={{ padding: "20px", background: "#f3f3f3", borderRadius: "10px" }}
    >
      <h2
        style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "10px" }}
      >
        React 19 Resource Loading APIs
      </h2>

      <p>
        This example demonstrates the use of <code>prefetchDNS()</code>,{" "}
        <code>preconnect()</code>, <code>preload()</code>, and{" "}
        <code>preinit()</code>.
      </p>

      {/* Image that benefits from preloading */}
      <img
        src="https://cdn.example.com/image.jpg"
        alt="Preloaded Example"
        style={{
          width: "100%",
          maxWidth: "400px",
          marginTop: "10px",
          borderRadius: "5px",
        }}
      />

      {/* External script that benefits from preinit */}
      <script src="https://cdn.example.com/script.js"></script>
    </div>
  );
}

/*
prefetchDNS()	Resolves DNS earlier to speed up connections
preconnect()	Establishes a connection to an external resource before it's needed
preload()	Preloads an asset (CSS, images, fonts, etc.) before the browser requests it
preinit()	Prepares scripts or modules ahead of time to avoid delays
*/
