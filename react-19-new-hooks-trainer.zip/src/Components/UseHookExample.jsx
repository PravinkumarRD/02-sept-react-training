"use client";

import { use, Suspense } from "react";

// Simulating an async data fetch function
const fetchData = async () => {
  return new Promise((resolve) =>
    setTimeout(() => resolve("Hello from use()! 🎉"), 2000)
  );
};

const asyncDataPromise = fetchData();

function AsyncComponent() {
  // use() hook reads the resolved value of the promise
  const data = use(asyncDataPromise);
  return <p className="text-lg font-semibold text-green-600">{data}</p>;
}

export default function UseHookExample() {
  return (
    <div className="p-5 bg-gray-100 rounded-lg">
      <h2 className="text-xl font-bold mb-4">React 19 use() Hook Demo</h2>
      <Suspense fallback={<p>Loading data...</p>}>
        <AsyncComponent />
      </Suspense>
    </div>
  );
}
