import "./App.css";
import PrefetchResourcesExample  from "./Components/PrefetchResourcesExample";
// import UseFormStatusHookExample from "./Components/UseFormStatusHookExample";
// import UseOptimisticExample from "./Components/UseOptimisticHookExample";
// import UseActionStateHookExample from "./Components/UseActionStateHookExample";
// import UseHookExample from "./Components/UseHookExample";
// import { DocumentMetadataExample } from "./Components/DocumentMetadataExample";

function App() {
  return (
    <>
      <h1>Welcome To React 19 Hooks!</h1>
      <hr />
      {/* <DocumentMetadataExample /> */}
      {/* <UseHookExample /> */}
      {/* <UseActionStateHookExample/> */}
      {/* <UseFormStatusHookExample /> */}
      {/* <UseOptimisticExample /> */}
      <PrefetchResourcesExample />
    </>
  );
}

export default App;
